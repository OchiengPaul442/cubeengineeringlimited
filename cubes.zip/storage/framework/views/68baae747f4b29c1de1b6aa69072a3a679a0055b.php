<canvas id="message-chart"></canvas>

<?php $__env->startSection('scripts'); ?>
    <script>
        var jan = JSON.parse(<?php echo json_encode($jan); ?>);
        var feb = JSON.parse(<?php echo json_encode($feb); ?>);
        var mar = JSON.parse(<?php echo json_encode($mar); ?>);
        var apr = JSON.parse(<?php echo json_encode($apr); ?>);
        var may = JSON.parse(<?php echo json_encode($may); ?>);
        var jun = JSON.parse(<?php echo json_encode($jun); ?>);
        var jul = JSON.parse(<?php echo json_encode($jul); ?>);
        var aug = JSON.parse(<?php echo json_encode($aug); ?>);
        var sep = JSON.parse(<?php echo json_encode($sep); ?>);
        var oct = JSON.parse(<?php echo json_encode($oct); ?>);
        var nov = JSON.parse(<?php echo json_encode($nov); ?>);
        var dec = JSON.parse(<?php echo json_encode($dec); ?>);
    </script>
    <script>
        const labels = [
            'January',
            'February',
            'March',
            'April',
            'May',
            'June',
            'July',
            'August',
            'September',
            'October',
            'November',
            'December'
        ];

        const data = {
            labels: labels,
            datasets: [{
                label: 'Client Messages',
                backgroundColor: 'rgb(255, 99, 132)',
                borderColor: 'rgb(255, 99, 132)',
                data: [jan, feb, mar, apr, may, jun, jul, aug, sep, oct, nov, dec],
            }]
        };

        const config1 = {
            type: 'line',
            data: data,
            options: {
                indexAxis: 'y',
                scales: {
                    x: {
                        beginAtZero: true
                    }
                }
            }
        };
    </script>
    <script>
        const messages = new Chart(
            document.getElementById('message-chart'),
            config1
        );
    </script>
<?php $__env->stopSection(); ?>
<?php /**PATH D:\workspace\projects\Cube Engineering\CubeEX\resources\views/Admin/components/charts/messages.blade.php ENDPATH**/ ?>