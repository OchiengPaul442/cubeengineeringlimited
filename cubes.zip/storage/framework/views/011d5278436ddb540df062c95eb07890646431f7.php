<form <?php if(Request::is('portfolio/*/edit')): ?> action="<?php echo e(route('portfolio.update', $portfolio->id)); ?>" <?php else: ?> action="<?php echo e(route('portfolio.store')); ?>" <?php endif; ?> class="mt-4 mb-3" enctype="multipart/form-data" method="POST">
    <?php echo csrf_field(); ?>
    <?php if(Request::is('portfolio/*/edit')): ?>
        <?php echo method_field('PUT'); ?>
    <?php else: ?>
        <?php echo method_field('POST'); ?>
    <?php endif; ?>
    <div class="mb-3">
        <label for="name" class="form-label">Portfolio name</label>
        <input type="text" class="form-control" name="name" id="name" placeholder=""
            <?php if(Request::is('portfolio/*/edit')): ?> value="<?php echo e($portfolio->name); ?>" <?php endif; ?>>
        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="text-danger"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="mb-3">
        <label for="status" class="form-label">Portfolio status</label>
        <select class="form-select" name="status" id="status" aria-label="Default select example">
            <option selected>
                <?php if(Request::is('portfolio/*/edit')): ?>
                    <?php echo e($portfolio->status); ?>

                <?php else: ?>
                    Open menu to select
                <?php endif; ?>
            </option>
            <option value="Complete">Complete</option>
            <option value="Running">Running</option>
            <option value="Upcoming">Upcoming</option>
        </select>
        <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="text-danger"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="mb-3">
        <label for="description" class="form-label">Brief Description</label>
        <textarea class="form-control" id="description" name="about">
            <?php if(Request::is('portfolio/*/edit')): ?>
<?php echo $portfolio->about; ?>

<?php endif; ?>
        </textarea>
        <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="text-danger"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="mb-3">
        <label class="mb-2">Image Upload</label>
        <input type="file" class="form-control" name="image" id="portfolioimage">
    </div>
    <?php if(Request::is('portfolio/*/edit')): ?>
    <div class="d-flex gap-3">
            <button type="submit" class="btn btn-success">Update portfolio</button>
            <a href="<?php echo e(route('portfolio.create')); ?>" class="btn btn-secondary">Undo</a>
        </div>
    <?php else: ?>
        <button type="submit" class="btn btn-primary">Upload portfolio</button>
    <?php endif; ?>
</form>
<?php /**PATH D:\workspace\projects\Cube Engineering\CubeEX\resources\views/Admin/components/forms/porfolio.blade.php ENDPATH**/ ?>