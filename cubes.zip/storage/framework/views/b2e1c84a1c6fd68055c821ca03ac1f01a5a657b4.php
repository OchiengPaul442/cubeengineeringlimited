<div>
    <div class="row d-flex gap-4 justify-content-around flex-wrap">
        <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="service-card">
                <input type="hidden" value="<?php echo e($service->id); ?>">
                <img src="<?php echo e(asset('storage/images/' . $service->image)); ?>" alt="">
                <div class="service-card-content">
                    <h2 class="service-card-title text-capitalize"><?php echo e($service->name); ?></h2>
                    <a href="<?php echo e(route('services.show', $service->id)); ?>" class="serivce-button">Learn
                        More</a>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div class="w-100">
        <?php if($services->hasMorePages()): ?>
            
            <div class="d-flex justify-content-center mt-5 mb-4 addmorebtn">
                <button wire:click="loadmore()" class="btn btn-primary" id="loadMore">Load More</button>
            </div>
        <?php else: ?>
            <?php if($services->count() > 4): ?>
                
                <div class="d-flex justify-content-center mt-5 mb-4 addmorebtn">
                    <button wire:click="loadless()" class="btn btn-primary" id="loadMore">Load Less</button>
                </div>
            <?php else: ?>
                
                <div class="d-flex justify-content-center mt-5 mb-4 addmorebtn">
                    <button class="btn btn-primary">No more Data</button>
                </div>
            <?php endif; ?>
        <?php endif; ?>
    </div>
</div>
<?php /**PATH D:\workspace\projects\Cube Engineering\CubeEX\resources\views/livewire/load-more.blade.php ENDPATH**/ ?>