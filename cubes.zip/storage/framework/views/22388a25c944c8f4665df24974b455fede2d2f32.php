<form
    <?php if(Request::is('testimonials/*/edit')): ?> action="<?php echo e(route('testimonials.update', $Testimonial->id)); ?>" <?php else: ?> action="<?php echo e(route('testimonials.store')); ?>" <?php endif; ?>
    class="mt-4 mb-3" enctype="multipart/form-data" method="POST">
    <?php echo csrf_field(); ?>
    <?php if(Request::is('testimonials/*/edit')): ?>
        <?php echo method_field('PUT'); ?>
    <?php else: ?>
        <?php echo method_field('POST'); ?>
    <?php endif; ?>
    <div class="mb-3">
        <label for="name" class="form-label">Customer name</label>
        <input type="text" class="form-control" name="name" id="name" placeholder=""
            <?php if(Request::is('testimonials/*/edit')): ?> value="<?php echo e($Testimonial->name); ?>" <?php endif; ?>>
        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="text-danger"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="mb-3">
        <label for="occupation" class="form-label">Customer occupation</label>
        <input type="text" class="form-control" name="occupation" id="occupation" placeholder=""
            <?php if(Request::is('testimonials/*/edit')): ?> value="<?php echo e($Testimonial->occupation); ?>" <?php endif; ?>>
        <?php $__errorArgs = ['occupation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="text-danger"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="mb-3">
        <label for="comments" class="form-label">Comments</label>
        <textarea class="form-control" id="comments" name="comments">
            <?php if(Request::is('testimonials/*/edit')): ?>
<?php echo $Testimonial->comments; ?>

<?php endif; ?>
        </textarea>
        <?php $__errorArgs = ['comments'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="text-danger"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="mb-3">
        <label class="mb-2">Image Upload</label>
        <input type="file" class="form-control" name="image" id="testimonialimage">
    </div>
    <?php if(Request::is('testimonials/*/edit')): ?>
        <div class="d-flex gap-3">
            <button type="submit" class="btn btn-success">Update Testimonial</button>
            <a href="<?php echo e(route('testimonials.create')); ?>" class="btn btn-secondary">Undo</a>
        </div>
    <?php else: ?>
        <button type="submit" class="btn btn-primary">Upload Testimonial</button>
    <?php endif; ?>
</form>
<?php /**PATH D:\workspace\projects\Cube Engineering\CubeEX\resources\views/Admin/components/forms/testimonials.blade.php ENDPATH**/ ?>