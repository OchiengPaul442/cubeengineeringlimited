<?php return array (
  'load-more' => 'App\\Http\\Livewire\\LoadMore',
);