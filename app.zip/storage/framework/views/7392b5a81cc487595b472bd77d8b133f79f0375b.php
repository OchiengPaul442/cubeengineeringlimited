<form
    <?php if(Request::is('services/*/edit')): ?> action="<?php echo e(route('services.update', $service->id)); ?>" <?php else: ?> action="<?php echo e(route('services.store')); ?>" <?php endif; ?>
    class="mt-4 mb-3" enctype="multipart/form-data" id="service-form" method="POST">
    <?php echo csrf_field(); ?>
    <?php if(Request::is('services/*/edit')): ?>
        <?php echo method_field('PUT'); ?>
        <input type="hidden" name="method" id="method-type" value="PUT">
    <?php else: ?>
        <?php echo method_field('POST'); ?>
        <input type="hidden" name="method" id="method-type" value="POST">
    <?php endif; ?>
    <div class="mb-3">
        <label for="name" class="form-label">Service name</label>
        <input type="text" class="form-control" name="name" id="name" placeholder=""
            <?php if(Request::is('services/*/edit')): ?> value="<?php echo e($service->name); ?>" <?php endif; ?>>
        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="message-block text-danger"><?php echo e($message); ?></p>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="mb-3">
        <label for="description" class="form-label">Brief Description</label>
        <input class="form-control" id="description" name="description"
       value = " <?php if(Request::is('services/*/edit')): ?>
            <?php echo e($service->description); ?>

        <?php endif; ?>">
        <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="message-block text-danger"><?php echo e($message); ?></p>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="mb-3">
        <label for="details" class="form-label">Details</label>
        <textarea class="form-control" id="details" name="details" style="height:150px;max-height: 200px">
            <?php if(Request::is('services/*/edit')): ?>
<?php echo e($service->details); ?>

<?php endif; ?>
        </textarea>
        <?php $__errorArgs = ['details'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="message-block text-danger"><?php echo e($message); ?></p>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    

    <div class="mb-3">
        <div class="mb-3">
            <label class="mb-2">Image Upload</label>
            <input type="file" name="image" id="serviceimage">
        </div>
    </div>
    <?php if(Request::is('services/*/edit')): ?>
        <button type="submit" class="btn btn-success">Update service</button>
    <?php else: ?>
        <button type="submit" class="btn btn-primary">Upload service</button>
    <?php endif; ?>
</form>
<?php /**PATH D:\workspace\Cube Engineering\CubeEX\resources\views/Admin/components/forms/services.blade.php ENDPATH**/ ?>