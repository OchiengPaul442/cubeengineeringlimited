
<?php if(session('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session('success')); ?>

    </div>
<?php elseif(session('fail')): ?>
    <div class="alert alert-danger">
        <?php echo e(session('fail')); ?>

    </div>
<?php endif; ?>
<?php /**PATH D:\workspace\Cube Engineering\CubeEX\resources\views/Admin/components/errors/notifications.blade.php ENDPATH**/ ?>