<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="shortcut icon" href="<?php echo e(asset('images/Group1.png')); ?>" type="image/x-icon">
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet"
        type="text/css">
    <link rel="stylesheet" href="<?php echo e(asset('/css/app.min.css')); ?>" type="text/css">
    
    <link rel="stylesheet" href="<?php echo e(asset('lib/flaticon/font/flaticon.css')); ?>" type="text/css">
    <link rel="stylesheet" href="<?php echo e(asset('lib/animate/animate.min.css')); ?>" type="text/css">
    <link rel="stylesheet" href="<?php echo e(asset('lib/slick/slick.css')); ?>" type="text/css">
    <link rel="stylesheet" href="<?php echo e(asset('lib/slick/slick-theme.css')); ?>" type="text/css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto&display=swap" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.6.1.min.js"
        integrity="sha256-o88AwQnZB+VDvE9tvIXrMQaPlFFSUTR+nldQm1LuPXQ=" crossorigin="anonymous"></script>
    <title><?php echo e($title); ?></title>
    <?php echo \Livewire\Livewire::styles(); ?>

</head>

<body>
    <div class="wrapper">
        
        <?php echo $__env->make('layout.site.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        

        <div class="page-header">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <h2>Our Services</h2>
                    </div>
                    <div class="col-12">
                        <a href="<?php echo e(route('home')); ?>">Home</a>
                        <a href="">Our Services</a>
                    </div>
                </div>
            </div>
        </div>

        
        <section class="service-display-details">
            <div class="container w-100 service-details">
                <h1><?php echo e($service->name); ?></h1>
                <span>Details</span>
                <div>
                    <?php echo $service->details; ?>

                </div>
            </div>
        </section>
        

        
        <section class="service">
            <div class="container">
                <div class="section-header text-center">
                    <p>Our Services</p>
                    <h2>We Provide Services</h2>
                </div>
                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('load-more', [])->html();
} elseif ($_instance->childHasBeenRendered('PGC88cO')) {
    $componentId = $_instance->getRenderedChildComponentId('PGC88cO');
    $componentTag = $_instance->getRenderedChildComponentTagName('PGC88cO');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('PGC88cO');
} else {
    $response = \Livewire\Livewire::mount('load-more', []);
    $html = $response->html();
    $_instance->logRenderedChild('PGC88cO', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
            </div>
        </section>
        

        
        <section id="facts">
            <div class="fact">
                <div class="container-fluid">
                    <div class="row counters">
                        <div class="col-md-6 fact-left wow slideInLeft">
                            <div class="row">
                                <div class="col-6">
                                    <div class="fact-icon">
                                        <i class="flaticon-worker"></i>
                                    </div>
                                    <div class="fact-text">
                                        <h2 data-toggle="counter-up">16</h2>
                                        <p>Expert Workers</p>
                                    </div>
                                </div>
                                <div class="col-6">
                                    <div class="fact-icon">
                                        <i class="flaticon-building"></i>
                                    </div>
                                    <div class="fact-text">
                                        <h2 data-toggle="counter-up">29</h2>
                                        <p>Happy Clients</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 fact-right wow slideInRight">
                            <div class="row">
                                <div class="col-6">
                                    <div class="fact-icon">
                                        <i class="flaticon-address"></i>
                                    </div>
                                    <div class="fact-text">
                                        <h2 data-toggle="counter-up">29</h2>
                                        <p>Completed Projects</p>
                                    </div>
                                </div>
                                <div class="col-6">
                                    <div class="fact-icon">
                                        <i class="flaticon-crane"></i>
                                    </div>
                                    <div class="fact-text">
                                        <span class="d-flex gap-2">
                                            <h2 data-toggle="counter-up">10</h2><span class="fs-3">+</span>
                                        </span>
                                        <p>Running Projects</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        


        
        <section id="FAQs">
            <div class="faqs">
                <div class="container">
                    <div class="section-header text-center">
                        <p>People Also Asked</p>
                        <h2>You May Ask</h2>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <div id="accordion-1">
                                <?php $__currentLoopData = $FAQs->slice(0, 5); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $FAQ): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="card wow fadeInLeft" data-wow-delay="0.1s">
                                        <div class="card-header">
                                            <a class="card-link collapsed" data-toggle="collapse"
                                                href="#collapse<?php echo e($FAQ->id); ?>">
                                                <?php echo e($FAQ->question); ?>

                                            </a>
                                        </div>
                                        <div id="collapse<?php echo e($FAQ->id); ?>" class="collapse"
                                            data-parent="#accordion-1">
                                            <div class="card-body">
                                                <?php echo e($FAQ->answer); ?>

                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div id="accordion-2">
                                <?php $__currentLoopData = $FAQs->slice(5, 10); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $FAQ): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="card wow fadeInRight" data-wow-delay="0.<?php echo e($FAQ->id); ?>s">
                                        <div class="card-header">
                                            <a class="card-link collapsed" data-toggle="collapse"
                                                href="#collapse<?php echo e($FAQ->id); ?>">
                                                <?php echo e($FAQ->question); ?>

                                            </a>
                                        </div>
                                        <div id="collapse<?php echo e($FAQ->id); ?>" class="collapse"
                                            data-parent="#accordion-2">
                                            <div class="card-body">
                                                <?php echo e($FAQ->answer); ?>

                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        


        
        <?php echo $__env->make('layout.site.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        
    </div>
    
    <section>
        <span class="floating-call-btn">
            <a href="tel:+256776024658">
                <i class="fa fa-phone my-float"></i>
            </a>
        </span>
    </section>
    

    
    <?php echo $__env->make('components.Button.scrolltotop', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    
    <?php echo $__env->make('components.loaders.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <script src="<?php echo e(asset('/js/app.js')); ?>"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.bundle.min.js"></script>
    <script src="<?php echo e(asset('/lib/easing/easing.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/lib/wow/wow.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/lib/slick/slick.min.js')); ?>"></script>
    <?php echo \Livewire\Livewire::scripts(); ?>

</body>

</html>
<?php /**PATH D:\workspace\Cube Engineering\CubeEX\resources\views/pages/service.blade.php ENDPATH**/ ?>