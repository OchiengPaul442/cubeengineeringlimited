<div class="row">
    <h6 class="mb-0">Old Password</h6>
    <div class="col-sm-12 text-secondary">
        <input class="w-100 outline-none border-none form-group" type="password" name="oldpassword">
        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="text-danger"><?php echo e($message); ?></span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
</div>
<hr>
<div class="row">
    <h6 class="mb-0">New Password</h6>
    <div class="col-sm-12 text-secondary">
        <input class="w-100 outline-none border-none" type="password" name="password">
        <?php $__errorArgs = ['newpassword'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="text-danger"><?php echo e($message); ?></span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
</div>
<hr>
<div class="row">
    <h6 class="mb-0">Confirm new Password</h6>
    <div class="col-sm-12 text-secondary">
        <input class="w-100 outline-none border-none" type="password" name="cpassword">
        <?php $__errorArgs = ['cpassword'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="text-danger"><?php echo e($message); ?></span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
</div>
<hr>
<?php /**PATH D:\workspace\Cube Engineering\CubeEX\resources\views/Admin/components/forms/changepwd.blade.php ENDPATH**/ ?>