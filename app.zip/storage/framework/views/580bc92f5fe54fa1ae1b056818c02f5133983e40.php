<?php
    if(!session()->has('userID')){
        header('Location: /login');
        exit;
    }
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo e($title); ?></title>
    
    <link rel="shortcut icon" href="<?php echo e(asset('images/Group1.png')); ?>" type="image/x-icon">
    <link href="<?php echo e(asset('css/admin.min.css')); ?>" rel="stylesheet" />
    
    <link href="https://unpkg.com/filepond@^4/dist/filepond.css" rel="stylesheet" />
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.12.1/css/jquery.dataTables.css">
    <script src="https://code.jquery.com/jquery-3.6.1.min.js"
        integrity="sha256-o88AwQnZB+VDvE9tvIXrMQaPlFFSUTR+nldQm1LuPXQ=" crossorigin="anonymous"></script>
</head>

<body class="sb-nav-fixed">
    
    <?php echo $__env->make('layout.admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div id="layoutSidenav">
        
        <div id="layoutSidenav_nav">
            <?php echo $__env->make('layout.admin.sideNav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <div id="layoutSidenav_content">
            
            <main>
                <?php echo $__env->yieldContent('content'); ?>
            </main>
            
            <?php echo $__env->make('layout.admin.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
    
    <?php echo $__env->make('Admin.components.modals.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('Admin.components.modals.others', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <script src="<?php echo e(asset('/js/admin.js')); ?>"></script>
    
    <script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.12.1/js/jquery.dataTables.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.bundle.min.js"></script>
    
    <script src="https://unpkg.com/filepond@^4/dist/filepond.js"></script>
        
    <script src="https://cdn.ckeditor.com/4.19.1/standard/ckeditor.js"></script>
        
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <?php echo $__env->yieldContent('scripts'); ?>
    <?php echo $__env->yieldContent('scripts2'); ?>
</body>

</html>
<?php /**PATH D:\workspace\Cube Engineering\CubeEX\resources\views/layout/admin/index.blade.php ENDPATH**/ ?>