<footer class="footer wow fadeIn" data-wow-delay="0.3s">
    <div class="container">
        <div class="row d-flex justify-content-between">
            <div class="col-md-6 col-lg-3">
                <div class="footer-contact">
                    <h2>Office Contact</h2>
                    <p class="text-uppercase"><i class="fa fa-map-marker-alt"></i>Blue Heights, Level 3 Nkrumah Rd</p>
                    <p class="text-uppercase"><a href="tel:+256 776024658"><i class="fa fa-phone-alt"></i>+256 776024658</a></p>
                    <p class="text-uppercase"><a href="tel:+256774764199"><i class="fa fa-phone-alt"></i>+256774764199</a></p>
                    <p class="text-uppercase"><a href="tel:+256708881648"><i class="fa fa-phone-alt"></i>+256708881648</a></p>
                    <p class=""><a href="mailto:cubeengineeringlimited@gmail.com"><i class="fa fa-envelope"></i>cubeengineeringlimited@gmail.com</a></p>
                    <div class="footer-social">
                        <a target="_blank" href="https://twitter.com/CubeEngineers?s=20&t=YOPh578w5sA3VX3KHRhieg"><i
                                class="fab fa-twitter"></i></a>
                                <a href="https://www.linkedin.com/company/cube-engineering-and-general-supplies-limited/"><i class="fab fa-linkedin-in"></i></a>
                        <a target="_blank" href="https://mail.google.com"><i class="fa fa-envelope"></i></a>
                        
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-lg-3">
                <div class="footer-link">
                    <h2>Services Areas</h2>
                    <?php
                        $services = App\Models\service::all();
                    ?>
                    <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(route('services.show', $service->id)); ?>"
                            class="text-uppercase"><?php echo e($service->name); ?></a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <div class="col-md-6 col-lg-3">
                <div class="footer-link">
                    <h2>Useful Pages</h2>
                    <?php if(Request::is('privacy', 'terms', 'services/*')): ?>
                        <a class="text-uppercase" href="<?php echo e(route('home')); ?>">About Us</a>
                        <a class="text-uppercase" href="<?php echo e(route('home')); ?>">Contact Us</a>
                        <a class="text-uppercase" href="<?php echo e(route('home')); ?>">Projects</a>
                        <a class="text-uppercase" href="<?php echo e(route('home')); ?>">Testimonial</a>
                    <?php else: ?>
                        <a class="text-uppercase" href="#about">About Us</a>
                        <a class="text-uppercase" href="#contact">Contact Us</a>
                        <a class="text-uppercase" href="#projects">Projects</a>
                        <a class="text-uppercase" href="#testimonials">Testimonial</a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    <div class="container footer-menu">
        <div class="f-menu">
            <a class="text-uppercase" href="<?php echo e(route('terms')); ?>">Terms of use</a>
            <a class="text-uppercase" href="<?php echo e(route('privacy')); ?>">Privacy policy</a>
        </div>
    </div>
    <div class="container copyright">
        <div class="row">
            <div class="col-md-6">
                <p class="text-uppercase">&copy; <a href="<?php echo e(route('home')); ?>">
                    Cube Engineering 
                    <?php
                        echo date('Y');
                    ?>
                </a>, All Right Reserved.</p>
            </div>
            <div class="col-md-6">
                <p class="text-uppercase">Designed By <a href="https://htmlcodex.com">HTML Codex</a></p>
            </div>
        </div>
    </div>
</footer>
<?php /**PATH D:\workspace\projects\Cube Engineering\CubeEX\resources\views/layout/site/footer.blade.php ENDPATH**/ ?>