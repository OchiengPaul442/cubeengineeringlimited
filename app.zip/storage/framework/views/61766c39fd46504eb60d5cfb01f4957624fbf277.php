<!-- Vertically centered modal -->
<div class="modal fade" tabindex="-1" id="changepwd">
    <div class="modal-dialog modal-dialog-centered">
        <form class="card-body" action="<?php echo e(route('portfolio.store', session('userID'))); ?>">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Change Password</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <?php echo $__env->make('Admin.components.forms.changepwd', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button class="btn btn-success " type="submit"
                        href="<?php echo e(route('portfolio.update', session('userID'))); ?>">Save changes</button>
                </div>
            </div>
        </form>
    </div>
</div>
<?php /**PATH D:\workspace\Cube Engineering\CubeEX\resources\views/components/modals/others.blade.php ENDPATH**/ ?>