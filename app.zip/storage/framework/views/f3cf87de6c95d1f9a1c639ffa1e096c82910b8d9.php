

<?php $__env->startSection('content'); ?>
    <div class="container-fluid mt-4 px-4 profile-body">
        
        <?php echo $__env->make('Admin.components.errors.notifications', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="container">
            <div class="main-body">

                <!-- Breadcrumb -->
                <nav aria-label="breadcrumb" class="main-breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('Admin.dashboard')); ?>">Home</a></li>
                        <li class="breadcrumb-item active" aria-current="page">User Profile</li>
                    </ol>
                </nav>
                <!-- /Breadcrumb -->

                <div class="row gutters-sm">
                    <div class="col-md-4 mb-3">
                        <div class="card">
                            <div class="card-body">
                                <div class="d-flex flex-column align-items-center text-center">
                                    <img src="https://bootdey.com/img/Content/avatar/avatar7.png" alt="Admin"
                                        class="rounded-circle" width="150">
                                    <div class="mt-3">
                                        <h4 class="text-capitalize"><?php echo e($user->name); ?></h4>
                                        <p class="text-secondary mb-1"><?php echo e($user->role); ?></p>
                                        <p class="text-muted font-size-sm"><?php echo e($user->address); ?></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="card mt-3">
                            <ul class="list-group list-group-flush">
                                <li class="list-group-item align-items-center">
                                    <a href="<?php echo e(route('home')); ?>" class="btn w-100" style="background: yellow">Go Site</a>
                                </li>
                                <li class="list-group-item align-items-center">
                                    <a href="" class="btn btn-info w-100"  data-bs-toggle="modal" data-bs-target="#changepwd">Change Password</a>
                                </li>
                                <li class="list-group-item align-items-center">
                                    <a href="" class="btn btn-danger w-100" data-bs-toggle="modal" data-bs-target="#deleteaccount">Delete account</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-md-8">
                        
                        <div class="card mb-3">
                            <?php echo $__env->make('Admin.components.forms.profile', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>

                        <div class="row gutters-sm">
                            <div class="col-sm-6 mb-3">
                                <div class="card h-100">
                                    <div class="card-body">
                                        <ul class="list-group list-group-flush h-100">
                                            <li class="list-group-item h-50"><a href="<?php echo e(route('portfolio.create')); ?>" class="h-100 w-100 d-flex justify-content-between btn btn-success postion-relative"><span class="fs-2">Projects</span><span class="fs-3 position-absolute" style="bottom: 15px;right:35px"><?php echo e($portfolio->count()); ?></span></a></li>
                                            <li class="list-group-item h-50"><a href="<?php echo e(route('messages.index')); ?>" class="h-100 w-100 d-flex justify-content-between btn btn-danger postion-relative"><span class="fs-2">Mail</span><span class="fs-3 position-absolute" style="bottom: 15px;right:35px"><?php echo e($messages->count()); ?></span></a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-6 mb-3">
                                <div class="card h-100">
                                    <div class="card-body">
                                        <ul class="list-group list-group-flush h-100">
                                            <li class="list-group-item h-50"><a href="<?php echo e(route('testimonials.create')); ?>" class="h-100 w-100 d-flex justify-content-between btn btn-warning postion-relative"><span class="fs-2">Testimonials</span><span class="fs-3 position-absolute" style="bottom: 15px;right:35px"><?php echo e($testimonial->count()); ?></span></a></li>
                                            <li class="list-group-item h-50"><a href="<?php echo e(route('services.create')); ?>" class="h-100 w-100 d-flex justify-content-between btn btn-secondary postion-relative"><span class="fs-2">Services</span><span class="fs-3 position-absolute" style="bottom: 15px;right:35px"><?php echo e($service->count()); ?></span></a></li>
                                            <li class="list-group-item h-50"><a href="<?php echo e(route('FAQs.create')); ?>" class="h-100 w-100 d-flex justify-content-between btn btn-dark postion-relative"><span class="fs-2">FAQs</span><span class="fs-3 position-absolute" style="bottom: 15px;right:35px"><?php echo e($FAQs->count()); ?></span></a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\workspace\projects\Cube Engineering\CubeEX\resources\views/Admin/pages/profile.blade.php ENDPATH**/ ?>