<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Google tag (gtag.js) -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=G-D6KEWR7KK8"></script>
    <script>
        window.dataLayer = window.dataLayer || [];

        function gtag() {
            dataLayer.push(arguments);
        }
        gtag('js', new Date());

        gtag('config', 'G-D6KEWR7KK8');
    </script>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    
    <link rel="shortcut icon" href="<?php echo e(asset('images/Group1.png')); ?>" type="image/x-icon">
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet"
        type="text/css">
    <link rel="stylesheet" href="<?php echo e(asset('/css/app.css')); ?>" type="text/css">
    
    <link rel="stylesheet" href="<?php echo e(asset('lib/flaticon/font/flaticon.css')); ?>" type="text/css">
    <link rel="stylesheet" href="<?php echo e(asset('lib/animate/animate.min.css')); ?>" type="text/css">
    <link rel="stylesheet" href="<?php echo e(asset('lib/owlcarousel/assets/owl.carousel.min.css')); ?>" type="text/css">
    <link rel="stylesheet" href="<?php echo e(asset('lib/lightbox/css/lightbox.min.css')); ?>" type="text/css">
    <link rel="stylesheet" href="<?php echo e(asset('lib/slick/slick.css')); ?>" type="text/css">
    <link rel="stylesheet" href="<?php echo e(asset('lib/slick/slick-theme.css')); ?>" type="text/css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto&display=swap" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.6.1.min.js"
        integrity="sha256-o88AwQnZB+VDvE9tvIXrMQaPlFFSUTR+nldQm1LuPXQ=" crossorigin="anonymous"></script>
    <title><?php echo e($title); ?></title>
    <?php echo \Livewire\Livewire::styles(); ?>

</head>

<body>
    <div class="wrapper">
        
        <?php echo $__env->make('layout.site.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        
        <?php echo $__env->make('components.carousels.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- Feature Start-->
        <div class="feature wow fadeInUp" data-wow-delay="0.1s">
            <div class="container-fluid">
                <div class="row align-items-center">
                    <div class="col-lg-4 col-md-12">
                        <div class="feature-item">
                            <div class="feature-icon">
                                <i class="flaticon-worker"></i>
                            </div>
                            <div class="feature-text">
                                <h3>Expert Worker</h3>
                                <?php if (isset($component)) { $__componentOriginalcd9972c8156dfa6e5fd36675ca7bf5f21b506e2e = $component; } ?>
<?php $component = $__env->getContainer()->make(BladeUI\Icons\Components\Svg::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('carbon-checkmark-outline'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(BladeUI\Icons\Components\Svg::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['style' => 'width:45px; color:orange']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcd9972c8156dfa6e5fd36675ca7bf5f21b506e2e)): ?>
<?php $component = $__componentOriginalcd9972c8156dfa6e5fd36675ca7bf5f21b506e2e; ?>
<?php unset($__componentOriginalcd9972c8156dfa6e5fd36675ca7bf5f21b506e2e); ?>
<?php endif; ?>

                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-12">
                        <div class="feature-item">
                            <div class="feature-icon">
                                <i class="flaticon-building"></i>
                            </div>
                            <div class="feature-text">
                                <h3>Quality Work</h3>
                                <?php if (isset($component)) { $__componentOriginalcd9972c8156dfa6e5fd36675ca7bf5f21b506e2e = $component; } ?>
<?php $component = $__env->getContainer()->make(BladeUI\Icons\Components\Svg::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('carbon-checkmark-outline'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(BladeUI\Icons\Components\Svg::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['style' => 'width:45px; color:orange']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcd9972c8156dfa6e5fd36675ca7bf5f21b506e2e)): ?>
<?php $component = $__componentOriginalcd9972c8156dfa6e5fd36675ca7bf5f21b506e2e; ?>
<?php unset($__componentOriginalcd9972c8156dfa6e5fd36675ca7bf5f21b506e2e); ?>
<?php endif; ?>

                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-12">
                        <div class="feature-item">
                            <div class="feature-icon">
                                <i class="flaticon-call"></i>
                            </div>
                            <div class="feature-text">
                                <h3>24/7 Support</h3>
                                <?php if (isset($component)) { $__componentOriginalcd9972c8156dfa6e5fd36675ca7bf5f21b506e2e = $component; } ?>
<?php $component = $__env->getContainer()->make(BladeUI\Icons\Components\Svg::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('carbon-checkmark-outline'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(BladeUI\Icons\Components\Svg::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['style' => 'width:45px; color:orange']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcd9972c8156dfa6e5fd36675ca7bf5f21b506e2e)): ?>
<?php $component = $__componentOriginalcd9972c8156dfa6e5fd36675ca7bf5f21b506e2e; ?>
<?php unset($__componentOriginalcd9972c8156dfa6e5fd36675ca7bf5f21b506e2e); ?>
<?php endif; ?>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Feature End-->

        
        <section id="about">
            <div class="about-container-wrapper">
                <div id="about" class="about wow fadeInUp" data-wow-delay="0.1s">
                    <div class="container">
                        <div class="row align-items-center">
                            <div class="col-lg-5 col-md-6">
                                <div class="about-img">
                                    <img src="<?php echo e(asset('images/Premium Photo Future building construction engineering project_.jpg')); ?>"
                                        alt="Image">
                                </div>
                            </div>
                            <div class="col-lg-7 col-md-6">
                                <div class="section-header text-left">
                                    <h2 class="fw-bold mb-2">Cube Engineering And General Supplies Limited</h2>
                                    <small>SERVE YOU BETTER</small>
                                    <div class="Line mt-4 mb-4"></div>
                                    <p>About Us</p>
                                </div>
                                <div class="about-text">
                                    <p>
                                        Cube Engineering and General Supplies Ltd is a multi-disciplinary engineering
                                        firm
                                        duly
                                        registered as a limited Company with an aim to provide quality services in the
                                        industry.
                                        Cube Engineering was founded on 7th March 2021 and incorporated on 14th July
                                        2021 in
                                        Kampala
                                        Uganda.
                                        <br>
                                        <br>
                                        Since its inception it has been at the forefront of providing a wide range of
                                        engineering services ranging from routine maintenance, Heavy duty machinery
                                        overhauls to
                                        turn key project management, implementation and Execution. Cube Engineering’s
                                        expertise
                                        has been developed from former employees of different organizations who have
                                        been
                                        involved in execution of number of construction, mechanical and electrical
                                        projects.
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="About_sec wow fadeInUp" id="about" data-wow-delay="0.2s">
                    <div class="Center">
                        <h3>More about us</h3>
                        <div class="Line mt-4"></div>
                        
                        <div class="Tabside">
                            <ul>
                                <li><a href="#" class="text-dark tabLink activeLink" id="cont-1">Mission</a>
                                </li>
                                <li><a href="#" class="text-dark tabLink" id="cont-2">vision</a></li>
                                <li><a href="#" class="text-dark tabLink" id="cont-3">Values</a></li>
                            </ul>
                            <div class="clear"></div>
                            <div class="tabcontent" id="cont-1-1">
                                <div class="TabImage">
                                    <div class="img1">
                                        <figure><img src="<?php echo e(asset('images/vision.jpg')); ?>" alt="image"></figure>
                                    </div>
                                    <div class="img2">
                                        <figure><img src="<?php echo e(asset('images/1663739612016 1.jpg')); ?>" alt="image">
                                        </figure>
                                    </div>
                                </div>
                                <div class="Description">
                                    <h3>Our Mission</h3>
                                    <p>
                                        To be the leader in offering the highest degree of technical and operational
                                        efficiency for
                                        our
                                        clients through provision of high quality engineering work.
                                    </p>
                                </div>
                            </div>
                            <div class="tabcontent hide" id="cont-2-1">
                                <div class="TabImage">
                                    <div class="img1">
                                        <figure><img src="<?php echo e(asset('images/vision.jpg')); ?>" alt="image"></figure>
                                    </div>
                                    <div class="img2">
                                        <figure><img src="<?php echo e(asset('images/augst 002.jpg')); ?>" alt="image">
                                        </figure>
                                    </div>
                                </div>
                                <div class="Description">
                                    <h3>Our Vision</h3>
                                    <p>
                                        To be the leading Services Provider in the engineering sector with high focus on
                                        Customer
                                        Satisfaction
                                    </p>
                                </div>
                            </div>
                            <div class="tabcontent hide" id="cont-3-1">
                                <div class="TabImage">
                                    <div class="img1">
                                        <figure><img src="<?php echo e(asset('images/vision.jpg')); ?>" alt="image"></figure>
                                    </div>
                                    <div class="img2">
                                        <figure><img src="<?php echo e(asset('images/SEPT 02.jpg')); ?>" alt="image">
                                        </figure>
                                    </div>
                                </div>
                                <div class="Description">
                                    <h3>Our Core Values</h3>
                                    <p><span>Integrity:</span> Honesty and strong moral principles.</p>
                                    <p><span>Customer Satisfaction:</span> Exceed customer expectations.</p>
                                    <p><span>Professionalism:</span> Skill, good judgement and individual adherence to
                                        the
                                        set
                                        standards.</p>
                                    <p><span>Innovation:</span> Take pro-active steps to drive performance.</p>
                                    <p><span>Teamwork:</span> Collaborate with others to achieve company goals.</p>
                                </div>
                            </div>
                            <div class="clear"></div>
                        </div>
                        
                    </div>
                </div>
            </div>
        </section>
        

        
        <section id="facts">
            <div class="fact">
                <div class="container-fluid">
                    <div class="row counters">
                        <div class="col-md-6 fact-left wow slideInLeft">
                            <div class="row">
                                <div class="col-6">
                                    <div class="fact-icon">
                                        <i class="flaticon-worker"></i>
                                    </div>
                                    <div class="fact-text">
                                        <h2 data-toggle="counter-up">16</h2>
                                        <p>Expert Workers</p>
                                    </div>
                                </div>
                                <div class="col-6">
                                    <div class="fact-icon">
                                        <i class="flaticon-building"></i>
                                    </div>
                                    <div class="fact-text">
                                        <h2 data-toggle="counter-up">29</h2>
                                        <p>Happy Clients</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 fact-right wow slideInRight">
                            <div class="row">
                                <div class="col-6">
                                    <div class="fact-icon">
                                        <i class="flaticon-address"></i>
                                    </div>
                                    <div class="fact-text">
                                        <h2 data-toggle="counter-up">29</h2>
                                        <p>Completed Projects</p>
                                    </div>
                                </div>
                                <div class="col-6">
                                    <div class="fact-icon">
                                        <i class="flaticon-crane"></i>
                                    </div>
                                    <div class="fact-text">
                                        <span class="d-flex gap-2">
                                            <h2 data-toggle="counter-up">10</h2><span class="fs-3">+</span>
                                        </span>
                                        <p>Running Projects</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        

        
        <section id="services">
            <div class="service wow fadeInUp">
                <div class="section-header text-center">
                    <p>Our Services</p>
                    <h2>Services We Provide</h2>
                </div>
                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('load-more', [])->html();
} elseif ($_instance->childHasBeenRendered('44f2el0')) {
    $componentId = $_instance->getRenderedChildComponentId('44f2el0');
    $componentTag = $_instance->getRenderedChildComponentTagName('44f2el0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('44f2el0');
} else {
    $response = \Livewire\Livewire::mount('load-more', []);
    $html = $response->html();
    $_instance->logRenderedChild('44f2el0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
            </div>
        </section>
        

        
        <section id="portfolio" class="wow fadeIn">
            <div class="section-header text-center">
                <p>Projects</p>
                <h2>Our Projects</h2>
            </div>
            <div class="container-fluid bg-portfolio py-5">
                <div class="container py-5">
                    <div class="row m-0 portfolio-container">
                        <?php $__currentLoopData = $portfolio; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $portfolios): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-lg-4 col-md-6 col-sm-12 p-0 portfolio-item">
                                <div class="position-relative overflow-hidden">
                                    <div class="portfolio-img">
                                        <img class="img-fluid w-100"
                                            src="<?php echo e(asset('/storage/images/' . $portfolios->image)); ?>"
                                            alt="">
                                    </div>
                                    <div class="portfolio-text">
                                        <h4 class="font-weight-bold mb-4"><?php echo e($portfolios->name); ?></h4>
                                        <div class="d-flex flex-column align-items-center justify-content-center">
                                            <p class="text-center" class="text-center"><?php echo $portfolios->about; ?></p>
                                            </p>
                                            <a class="btn btn-sm btn-secondary m-1"
                                                href="<?php echo e(asset('/storage/images/' . $portfolios->image)); ?>"
                                                data-lightbox="portfolio">
                                                <i class="fa fa-eye"></i>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>
                </div>
            </div>
        </section>
        

        
        <section id="FAQs">
            <div class="faqs">
                <div class="container">
                    <div class="section-header text-center">
                        <p>Frequently Asked Question</p>
                        <h2>You May Ask</h2>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <div id="accordion-1">
                                <?php $__currentLoopData = $FAQs->slice(0, 5); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $FAQ): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="card wow fadeInLeft" data-wow-delay="0.1s">
                                        <div class="card-header">
                                            <a class="card-link collapsed" data-toggle="collapse"
                                                href="#collapse<?php echo e($FAQ->id); ?>">
                                                <?php echo e($FAQ->question); ?>

                                            </a>
                                        </div>
                                        <div id="collapse<?php echo e($FAQ->id); ?>" class="collapse"
                                            data-parent="#accordion-1">
                                            <div class="card-body">
                                                <?php echo $FAQ->answer; ?>

                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div id="accordion-2">
                                <?php $__currentLoopData = $FAQs->slice(5, 10); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $FAQ): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="card wow fadeInRight" data-wow-delay="0.<?php echo e($FAQ->id); ?>s">
                                        <div class="card-header">
                                            <a class="card-link collapsed" data-toggle="collapse"
                                                href="#collapse<?php echo e($FAQ->id); ?>">
                                                <?php echo e($FAQ->question); ?>

                                            </a>
                                        </div>
                                        <div id="collapse<?php echo e($FAQ->id); ?>" class="collapse"
                                            data-parent="#accordion-2">
                                            <div class="card-body">
                                                <?php echo $FAQ->answer; ?>

                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        

        
        <section id="testimonials">
            <div class="testimonial wow fadeIn" data-wow-delay="0.1s">
                <div class="section-header text-center">
                    <p>Testimonials</p>
                    <h2 style="color: white">From Our Customers</h2>
                </div>
                <div class="container">
                    <div class="row">
                        <div class="col-12">
                            <div class="testimonial-slider-nav">
                                <?php $__currentLoopData = $testimonials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $testimonial): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="slider-nav">
                                        <img src="<?php echo e(asset('/storage/images/' . $testimonial->image)); ?>"
                                            alt="Testimonial">
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-12">
                            <div class="testimonial-slider">
                                <?php $__currentLoopData = $testimonials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $testimonial): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="slider-item">
                                        <h3><?php echo e($testimonial->customername); ?></h3>
                                        <h4><?php echo e($testimonial->occupation); ?></h4>
                                        <p><?php echo $testimonial->comments; ?>

                                        </p>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        

        
        <section id="contact">
            <!-- Contact Start -->
            <div class="contact wow fadeInUp">
                <div class="container">
                    <div class="section-header text-center">
                        <p>Get In Touch</p>
                        <h2>For Any Query</h2>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="contact-info">
                                <div class="contact-item">
                                    <i class="flaticon-address"></i>
                                    <div class="contact-text">
                                        <h2>Location</h2>
                                        <p>Blue Heights, Level 3 Nkrumah Rd</p>
                                    </div>
                                </div>
                                <div class="contact-item">
                                    <i class="flaticon-call"></i>
                                    <div class="contact-text">
                                        <h2>Phone</h2>
                                        <p>+256 776024658</p>
                                        <p>+256774764199</p>
                                        <p>+256708881648</p>
                                    </div>
                                </div>
                                <div class="contact-item">
                                    <i class="flaticon-send-mail"></i>
                                    <div class="contact-text">
                                        <h2>Email</h2>
                                        <p class="d-flex flex-wrap">cubeengineeringlimited@gmail.com</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-md-6">
                            <div class="contact-form">
                                <div id="success"></div>
                                <?php echo $__env->make('components.Forms.contact', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Contact End -->
        </section>
        

        
        <section id="partners">
            <div class="container wow fadeIn">
                <div class="section-header text-center">
                    <p>Partners</p>
                    <h2>Our key partners</h2>
                </div>
                <div class="text-center">
                    <div class="row align-items-center">
                        <div class="col">
                            <img width="280px" src="<?php echo e(asset('images/Strabag.svg.png')); ?>" alt="partner-logos">
                        </div>
                        <div class="col">
                            <img width="280px" src="<?php echo e(asset('images/image 4.svg')); ?>" alt="partner-logos">
                        </div>
                        <div class="col">
                            <img width="280px" src="<?php echo e(asset('images/image 5.svg')); ?>" alt="partner-logos">
                        </div>
                        <div class="col">
                            <img width="280px" src="<?php echo e(asset('images/image 6.svg')); ?>" alt="partner-logos">
                        </div>

                        <div class="col">
                            <img width="280px" src="<?php echo e(asset('images/image 7.svg')); ?>" alt="partner-logos">
                        </div>

                        <div class="col">
                            <img width="280px" src="<?php echo e(asset('images/image 9.svg')); ?>" alt="partner-logos">
                        </div>
                        <div class="col">
                            <img width="280px" src="<?php echo e(asset('images/image 8.svg')); ?>" alt="partner-logos">
                        </div>
                    </div>
                </div>
            </div>
        </section>
        

        
        <section id="timeline">
            <div class="container-fluid py-5 wow fadeIn">
                <div class="container py-5">
                    <div class="row align-items-end mb-4 timeline-head">
                        <div class="col-lg-6">
                            <h6 class="text-secondary font-weight-semi-bold text-uppercase mb-3">Daily Reminders</h6>
                            <h1 class="section-title mb-3">Always Deliver more than expected.</h1>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-12">
                            <div class="owl-carousel timeline-carousel position-relative">
                                <?php $__currentLoopData = $timeline; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $timeline): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="timeline d-flex flex-column text-center rounded overflow-hidden">
                                        <div class="position-relative">
                                            <div class="timeline-img">
                                                <img class="img-fluid w-100"
                                                    src="<?php echo e(asset('storage/images/' . $timeline->image)); ?>"
                                                    alt="">
                                            </div>
                                            <div
                                                class="timeline-social d-flex flex-column align-items-center justify-content-center">
                                                <a target="_blank" class="btn btn-secondary btn-social mb-2"
                                                    href="https://twitter.com/CubeEngineers?s=20&t=YOPh578w5sA3VX3KHRhieg"><i
                                                        class="fab fa-twitter"></i></a>
                                                <a target="_blank" class="btn btn-secondary btn-social mb-2"
                                                    href="https://www.linkedin.com/company/cube-engineering-and-general-supplies-limited/"><i
                                                        class="fab fa-linkedin-in"></i></a>
                                            </div>
                                        </div>
                                        <div class="d-flex flex-column timeline-text text-center py-4">
                                            <h5 class="font-weight-bold"><?php echo e($timeline->title); ?></h5>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </section>
        

        
        <section>
            <iframe
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3989.7594577220207!2d32.58001141521419!3d0.31122996411729714!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x177dbdd0eca93c03%3A0x38c6dc5b1d215262!2sBlue%20Heights!5e0!3m2!1sen!2sug!4v1663617359157!5m2!1sen!2sug"
                width="100%" height="600" style="border:0;" allowfullscreen="" loading="lazy"
                referrerpolicy="no-referrer-when-downgrade" class="mt-5"></iframe>
        </section>
        

        
        <section>
            <span class="floating-call-btn">
                <a href="tel:+256776024658">
                    <i class="fa fa-phone my-float"></i>
                </a>
            </span>
        </section>
        

        
        <?php echo $__env->make('components.modals.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        

        
        <?php echo $__env->make('layout.site.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        
        <?php echo $__env->make('components.Button.scrolltotop', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    
    <?php echo $__env->make('components.loaders.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.bundle.min.js"></script>
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
    <script src="<?php echo e(asset('lib/wow/wow.min.js')); ?>"></script>
    <script src="<?php echo e(asset('lib/owlcarousel/owl.carousel.min.js')); ?>"></script>
    <script src="<?php echo e(asset('lib/lightbox/js/lightbox.min.js')); ?>"></script>
    <script src="<?php echo e(asset('lib/waypoints/waypoints.min.js')); ?>"></script>
    <script src="<?php echo e(asset('lib/counterup/counterup.min.js')); ?>"></script>
    <script src="<?php echo e(asset('lib/slick/slick.min.js')); ?>"></script>
    <?php echo \Livewire\Livewire::scripts(); ?>

</body>

</html>
<?php /**PATH D:\workspace\projects\Cube Engineering\CubeEX\resources\views/layout/site/app.blade.php ENDPATH**/ ?>