<form
    <?php if(Request::is('timeline/*/edit')): ?> action="<?php echo e(route('timeline.update', $timeline->id)); ?>" <?php else: ?> action="<?php echo e(route('timeline.store')); ?>" <?php endif; ?>
    class="mt-4 mb-3" enctype="multipart/form-data" method="POST">
    <?php echo csrf_field(); ?>
    <?php if(Request::is('timeline/*/edit')): ?>
        <?php echo method_field('PUT'); ?>
    <?php else: ?>
        <?php echo method_field('POST'); ?>
    <?php endif; ?>
    <div class="mb-3">
        <label for="quote" class="form-label">Daily Quotes</label>
        <input type="text" class="form-control" name="quote" id="quote" placeholder=""
            <?php if(Request::is('timeline/*/edit')): ?> value="<?php echo e($timeline->quote); ?>" <?php endif; ?>>
        <?php $__errorArgs = ['quote'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="text-danger"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="mb-3">
        <label for="title" class="form-label">Title</label>
        <input type="text" class="form-control" name="title" id="title" placeholder=""
            <?php if(Request::is('timeline/*/edit')): ?> value="<?php echo e($timeline->title); ?>" <?php endif; ?>>
        <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="text-danger"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="mb-3">        
        <label class="mb-2">Image Upload</label>
        <input type="file" class="" name="image" id="timelineimage">
    </div>


    <?php if(Request::is('timeline/*/edit')): ?>
        <button type="submit" class="btn btn-success">Update timeline</button>
    <?php else: ?>
        <button type="submit" class="btn btn-primary">Upload timeline</button>
    <?php endif; ?>
</form>
<?php /**PATH D:\workspace\Cube Engineering\CubeEX\resources\views/Admin/components/forms/timeline.blade.php ENDPATH**/ ?>