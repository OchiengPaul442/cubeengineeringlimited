<div id="loader-wrapper">
    <span class="con-spin">
        <div id="loader"></div>
        <span class="innerpoint">
            <img src="<?php echo e(asset('images/Group1.png')); ?>" alt="">
        </span>
    </span>
    <div class="loader-section section-left"></div>
    <div class="loader-section section-right"></div>
</div>
<?php /**PATH D:\workspace\Cube Engineering\CubeEX\resources\views/components/loaders/main.blade.php ENDPATH**/ ?>