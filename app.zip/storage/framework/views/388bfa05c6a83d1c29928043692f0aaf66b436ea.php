
<a href="#" class="back-to-top"><i class="fa fa-chevron-up"></i></a>
<?php /**PATH D:\workspace\Cube Engineering\CubeEX\resources\views/components/Button/scrolltotop.blade.php ENDPATH**/ ?>