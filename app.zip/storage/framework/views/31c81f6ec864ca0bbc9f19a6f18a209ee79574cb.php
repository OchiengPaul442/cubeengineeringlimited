<form
    <?php if(Request::is('FAQs/*/edit')): ?> action="<?php echo e(route('FAQs.update', $FAQ->id)); ?>" <?php else: ?> action="<?php echo e(route('FAQs.store')); ?>" <?php endif; ?>
    class="mt-4 mb-3" enctype="multipart/form-data" method="POST">
    <?php echo csrf_field(); ?>
    <?php if(Request::is('FAQs/*/edit')): ?>
        <?php echo method_field('PUT'); ?>
    <?php else: ?>
        <?php echo method_field('POST'); ?>
    <?php endif; ?>
    
    <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php elseif(session('fail')): ?>
        <div class="alert alert-danger">
            <?php echo e(session('fail')); ?>

        </div>
    <?php endif; ?>
    <div class="mb-3">
        <label for="question" class="form-label">Question</label>
        <input type="text" class="form-control" name="question" id="question" placeholder=""
            <?php if(Request::is('FAQs/*/edit')): ?> value="<?php echo e($FAQ->question); ?>" <?php endif; ?>>
        <?php $__errorArgs = ['question'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="text-danger"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="mb-3">
        <label for="question" class="form-label">Answer</label>
        <textarea class="form-control" id="answer" name="answer" >
            <?php if(Request::is('FAQs/*/edit')): ?>
<?php echo e($FAQ->answer); ?>

<?php endif; ?>
        </textarea>
        <?php $__errorArgs = ['question'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="text-danger"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <?php if(Request::is('FAQs/*/edit')): ?>
        <button type="submit" class="btn btn-success">Update FAQs</button>
    <?php else: ?>
        <button type="submit" class="btn btn-primary">Upload FAQs</button>
    <?php endif; ?>
</form>
<?php /**PATH D:\workspace\Cube Engineering\CubeEX\resources\views/Admin/components/forms/FAQs.blade.php ENDPATH**/ ?>