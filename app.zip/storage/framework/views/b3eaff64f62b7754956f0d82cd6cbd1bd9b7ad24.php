<div class="card-body">
    <form action="<?php echo e(route('Auth.update', $user->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php if(Request::is('Auth/*/edit')): ?>
            <?php echo method_field('PUT'); ?>
        <?php else: ?>
            <?php echo method_field('POST'); ?>
        <?php endif; ?>
        <div class="row">
            <div class="col-sm-3">
                <h6 class="mb-0">Full Name</h6>
            </div>
            <div class="col-sm-9 text-secondary">
                <input class="w-100 outline-none border-none" name="name"
                    <?php if(Request::is('Auth/*/edit')): ?> value="<?php echo e($user->name); ?>" <?php else: ?> value="<?php echo e($user->name); ?>" disabled <?php endif; ?>
                    type="text">
                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-danger"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>
        <hr>
        <div class="row">
            <div class="col-sm-3">
                <h6 class="mb-0">Email</h6>
            </div>
            <div class="col-sm-9 text-secondary">
                <input class="w-100 outline-none border-none" name="email"
                    <?php if(Request::is('Auth/*/edit')): ?> value="<?php echo e($user->email); ?>" <?php else: ?> value="<?php echo e($user->email); ?>" disabled <?php endif; ?>
                    type="email">
                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-danger"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>
        <hr>
        <div class="row">
            <div class="col-sm-3">
                <h6 class="mb-0">Role</h6>
            </div>
            <div class="col-sm-9 text-secondary">
                <input class="w-100 outline-none border-none" name="role"
                    <?php if(Request::is('Auth/*/edit')): ?> value="<?php echo e($user->role); ?>" <?php else: ?> value="<?php echo e($user->role); ?>" disabled <?php endif; ?>
                    type="text">
                <?php $__errorArgs = ['role'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-danger"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>
        <hr>
        <div class="row">
            <div class="col-sm-3">
                <h6 class="mb-0">Phone</h6>
            </div>
            <div class="col-sm-9 text-secondary">
                <input class="w-100 outline-none border-none" name="phone"
                    <?php if(Request::is('Auth/*/edit')): ?> value="<?php echo e($user->phone); ?>" <?php else: ?> value="<?php echo e($user->phone); ?>" disabled <?php endif; ?>
                    type="text">
                <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-danger"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>
        <hr>
        <div class="row">
            <div class="col-sm-3">
                <h6 class="mb-0">Address</h6>
            </div>
            <div class="col-sm-9 text-secondary">
                <input class="w-100 outline-none border-none" name="address"
                    <?php if(Request::is('Auth/*/edit')): ?> value="<?php echo e($user->address); ?>" <?php else: ?> value="<?php echo e($user->address); ?>" disabled <?php endif; ?>
                    type="text">
                <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-danger"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>
        <hr>
        <div class="w-100">
            <?php if(Request::is('Auth/*/edit')): ?>
                <div class="d-flex gap-3 col-sm-12">
                    <div class="">
                        <button class="btn btn-success " type="submit" href="">save
                            changes</button>
                        <a class="btn btn-secondary" href="<?php echo e(route('Auth.show', $user->id)); ?>">No</a>
                    </div>
                </div>
            <?php else: ?>
                <div class="col-sm-12">
                    <a class="btn btn-info" href="<?php echo e(route('Auth.edit', $user->id)); ?>">Edit</a>
                </div>
            <?php endif; ?>
        </div>
    </form>
</div>
<?php /**PATH D:\workspace\Cube Engineering\CubeEX\resources\views/Admin/components/forms/profile.blade.php ENDPATH**/ ?>