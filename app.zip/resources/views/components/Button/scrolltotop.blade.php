{{-- scroll to the etop button --}}
<a href="#" class="back-to-top"><i class="fa fa-chevron-up"></i></a>
