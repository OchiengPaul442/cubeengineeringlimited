<!-- Modal -->
<div class="modal fade" id="notification" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-body">
                <span class="success-message text-success"></span>
                <span class="fail-message text-danger"></span>
            </div>
        </div>
    </div>
</div>

